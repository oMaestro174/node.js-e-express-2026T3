async function buscarCep(cep) {
  const cepLimpo = String(cep).replace(/\D/g, "");

  if (cepLimpo.length !== 8) {
    throw new Error("CEP invalido. Use 8 digitos, ex: 01001000.");
  }

  const response = await fetch(`https://viacep.com.br/ws/${cepLimpo}/json/`);

  if (!response.ok) {
    throw new Error(`Erro HTTP ao consultar CEP: ${response.status}`);
  }

  const data = await response.json();

  if (data.erro) {
    throw new Error("CEP nao encontrado.");
  }

  return data;
}

(async function main() {
  try {
    const dadosCep = await buscarCep("01001000");

    console.log("CEP:", dadosCep.cep);
    console.log("Logradouro:", dadosCep.logradouro);
    console.log("Bairro:", dadosCep.bairro);
    console.log("Cidade:", dadosCep.localidade);
    console.log("UF:", dadosCep.uf);
  } catch (erro) {
    console.error("Falha ao consultar CEP:", erro.message);
  }
})();
