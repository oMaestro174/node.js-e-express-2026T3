# Prática Guiada: A Evolução do Código Assíncrono (Consulta de CEP)

Nesta prática, vamos acompanhar a evolução dos padrões de código assíncrono no Node.js. Usaremos um exemplo prático e muito comum: consultar um endereço a partir de um CEP, utilizando a API pública [ViaCEP](https://viacep.com.br/).

Vamos implementar a mesma funcionalidade de três formas diferentes:

1.  **Callbacks (O Estilo Clássico)**
2.  **Promises (O Padrão Moderno)**
3.  **Async/Await (A Sintaxe Simplificada)**

Isso nos ajudará a entender as vantagens e desvantagens de cada abordagem e por que a comunidade Node.js migrou para as mais recentes.

---

## Passo 1: O Mundo dos Callbacks

Antigamente, o `request` era um pacote muito popular para fazer requisições HTTP. Ele usa o padrão de _callbacks_ para lidar com a resposta.

**Código de Exemplo:** `src/viacep-callback.js`

```javascript
const request = require("request");

function consultarCep(cep, callback) {
  const url = `https://viacep.com.br/ws/${cep}/json/`;

  request(url, { json: true }, (err, res, body) => {
    if (err) {
      return callback(err);
    }
    if (res.statusCode !== 200) {
      return callback(new Error(`Status Code: ${res.statusCode}`));
    }
    return callback(null, body);
  });
}

// Exemplo de uso
consultarCep("01001000", (err, endereco) => {
  if (err) {
    console.error("Ocorreu um erro:", err.message);
    return;
  }
  console.log("Endereço encontrado (Callback):");
  console.log(endereco);
});
```

**Para rodar:**

1.  Instale o `request`: `npm install request`
2.  Execute o arquivo: `node src/viacep-callback.js`

**Análise:**

- A função `consultarCep` recebe um _callback_ como argumento.
- Esse _callback_ segue o padrão `(error, result)`, onde o primeiro argumento é sempre reservado para um possível erro.
- Note o aninhamento e a necessidade de checar o erro (`if (err)`) antes de processar o sucesso. Isso pode levar ao famoso "Callback Hell" em cenários mais complexos.

---

## Passo 2: A Chegada das Promises

Com o tempo, as Promises se tornaram o padrão para lidar com assincronia, oferecendo uma forma mais limpa e encadeável de escrever o código. Pacotes como o `axios` foram criados com suporte nativo a Promises.

**Código de Exemplo:** `src/viacep-promise.js`

```javascript
const axios = require("axios");

function consultarCep(cep) {
  const url = `https://viacep.com.br/ws/${cep}/json/`;

  return axios.get(url).then((response) => response.data);
}

// Exemplo de uso
consultarCep("30130010")
  .then((endereco) => {
    console.log("Endereço encontrado (Promise):");
    console.log(endereco);
  })
  .catch((err) => {
    console.error("Ocorreu um erro:", err.message);
  });
```

**Para rodar:**

1.  Instale o `axios`: `npm install axios`
2.  Execute o arquivo: `node src/viacep-promise.js`

**Análise:**

- A função `consultarCep` agora retorna uma `Promise`.
- Usamos `.then()` para lidar com o caso de sucesso e `.catch()` para capturar qualquer erro na cadeia.
- O código fica mais "plano" e legível, evitando o aninhamento excessivo.

---

## Passo 3: Async/Await - A Sintaxe Síncrona para Código Assíncrono

O `async/await` é uma "açúcar sintático" em cima das Promises. Ele nos permite escrever código assíncrono que se parece e se comporta muito como código síncrono, tornando-o extremamente intuitivo.

**Código de Exemplo:** `src/viacep-async-await.js`

```javascript
const axios = require("axios");

async function consultarCep(cep) {
  try {
    const url = `https://viacep.com.br/ws/${cep}/json/`;
    const response = await axios.get(url);
    return response.data;
  } catch (err) {
    console.error("Ocorreu um erro na consulta:", err.message);
    // Lançar o erro novamente ou retornar um valor padrão
    throw err;
  }
}

// Exemplo de uso
async function main() {
  try {
    const endereco = await consultarCep("54440330");
    console.log("Endereço encontrado (Async/Await):");
    console.log(endereco);
  } catch (err) {
    console.error("Falha ao obter endereço:", err.message);
  }
}

main();
```

**Para rodar:**

1.  Se ainda não instalou, instale o `axios`: `npm install axios`
2.  Execute o arquivo: `node src/viacep-async-await.js`

**Análise:**

- A palavra-chave `async` antes da função nos permite usar o `await` dentro dela.
- O `await` pausa a execução da função `async` até que a Promise seja resolvida.
- O tratamento de erros é feito com o familiar bloco `try...catch`, que é uma forma muito natural de lidar com exceções.

## Conclusão

Ao comparar os três exemplos, fica claro por que `async/await` se tornou a abordagem preferida para a maioria dos desenvolvedores Node.js. Ele combina o poder das Promises com uma sintaxe limpa e fácil de entender, reduzindo a complexidade e melhorando a manutenibilidade do código.
