# Desafio: Batalha de Heróis (Sync vs. Async)

## Contexto

Neste desafio, você vai comparar duas versões de uma simulação de batalha:

- **Versão Síncrona:** O código em `src/star_wars_battle_sync.js` executa todos os rounds da batalha de uma vez, sem pausas.
- **Versão Assíncrona:** O código em `src/star_wars_battle_async.js` simula a batalha com pausas controladas entre os rounds, usando `Promise` e `async/await`.

O objetivo é entender, na prática, a diferença fundamental entre um fluxo de execução imediato (síncrono) e um fluxo que pode ser pausado para aguardar operações (assíncrono).

## Objetivos de Aprendizagem

Ao final deste desafio, você deverá ser capaz de:

1.  Explicar com suas palavras o que é um fluxo de execução síncrono e assíncrono.
2.  Identificar o papel do `await` em pausar a execução de uma função `async`.
3.  Executar e comparar os dois comportamentos no seu terminal.
4.  Implementar melhorias e novas funcionalidades em ambos os scripts.

---

## Parte 1: Preparação e Observação

1.  Abra o terminal na pasta do projeto.
2.  Execute os scripts separadamente para entender o comportamento de cada um.

### Etapa A: Versão Síncrona

Execute o comando:

```bash
node "src/star_wars_battle_sync.js"
```

**Observe:**

- Os resultados dos 3 rounds aparecem quase instantaneamente.
- Não existe nenhuma pausa visível entre um round e outro. O loop `for` executa todas as iterações o mais rápido possível.

**Anote suas impressões:**

- Quanto tempo a execução total parece levar?
- Em que momento o código "espera" por algo? (Se é que espera).

### Etapa B: Versão Assíncrona

Execute o comando:

```bash
node "src/star_wars_battle_async.js"
```

**Observe:**

- Existe uma pausa clara antes de cada round começar.
- A mensagem "localizando alvos e preparando para o próximo round..." aparece, e só depois de um tempo o round seguinte é exibido.
- A função `await esperar(1500)` é a responsável por controlar o ritmo da simulação.

**Anote suas impressões:**

- Qual foi a sensação de tempo entre os rounds?
- Qual linha de código é a chave para criar esse comportamento de "espera"?

---

## Parte 2: Mão na Massa - Implemente as Melhorias

Agora é sua vez de modificar o código!

### Tarefa 1: Aumentar o Número de Rounds

- **O quê?** Altere as **duas versões** (`sync` e `async`) para que a batalha tenha **5 rounds** em vez de 3.
- **Por quê?** Para verificar se o comportamento observado se mantém com mais iterações.

### Tarefa 2: Declarar o Vencedor

- **O quê?** Em ambas as versões, some os pontos de ataque de cada personagem ao longo de todos os rounds. Ao final da batalha, exiba uma mensagem declarando o vencedor (quem teve a maior soma de pontos) ou se houve um "Empate".
- **Por quê?** Para praticar o gerenciamento de estado (acumular valores) em ambos os paradigmas.

### Tarefa 3: Delay Configurável (Apenas na versão `async`)

- **O quê?** No arquivo `star_wars_battle_async.js`, crie uma constante no topo do arquivo para controlar o tempo de espera.
  ```javascript
  const DELAY_MS = 1000; // 1 segundo
  ```
  Use essa variável na função `esperar()`. Teste o script com valores diferentes (ex: 500, 1000, 2000) e descreva como isso afeta a "experiência" da simulação.
- **Por quê?** Para aprender a criar configurações flexíveis em seu código.

### Tarefa 4: Log de Tempo por Rodada (Apenas na versão `async`)

- **O quê?** Modifique o `star_wars_battle_async.js` para exibir um timestamp (data e hora) no início de cada round. O resultado esperado é algo como:
  ```
  [14:35:10] Round 1 iniciado
  ...
  [14:35:11] Round 2 iniciado
  ...
  ```
- **Por quê?** Para comprovar visualmente que o intervalo de tempo entre os rounds corresponde ao `DELAY_MS` configurado.

---

## Parte 3: Reflexão

Após completar as tarefas, responda em um arquivo de texto ou em suas anotações:

1.  Por que usar `async/await` em uma função que não tem uma espera real (como uma Promise que se resolve com `setTimeout`) não muda muito a experiência do usuário?
2.  Dê um exemplo de um tipo de aplicação ou funcionalidade onde um fluxo assíncrono é **essencial** (ex: consultar um banco de dados, fazer uma chamada de API, ler um arquivo grande).
3.  Na sua opinião, o que acontece com a facilidade de ler o código quando adicionamos muitas pausas e lógicas assíncronas?

---

## Entrega

Para concluir o desafio, você deve entregar:

1.  O código-fonte atualizado do arquivo `src/star_wars_battle_sync.js`.
2.  O código-fonte atualizado do arquivo `src/star_wars_battle_async.js`.
3.  Um pequeno texto (5 a 10 linhas) em um arquivo `REFLEXAO.md` com suas respostas da Parte 3.

## Critérios de Avaliação

- **Execução:** Os dois scripts rodam sem erros.
- **Implementação:** As 4 tarefas foram implementadas corretamente.
- **Clareza:** A diferença entre síncrono e assíncrono é explicada com clareza na reflexão.
- **Análise:** A análise final sobre o impacto da assincronia é coerente.

### Bônus (Opcional)

- Adicione um terceiro personagem à batalha em ambas as versões.
- Crie um modo "batalha rápida" na versão assíncrona, que usa um delay de apenas 200ms.
- Mostre um ranking final com a pontuação de cada personagem, do maior para o menor.
