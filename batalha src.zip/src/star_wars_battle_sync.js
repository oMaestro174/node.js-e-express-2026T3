// --- VERSÃO SÍNCRONA ---
// Tudo aqui acontece "na hora". O Node não espera nada.

const pilot = { nome: "Luke", poder: 4 };
const enemy = { nome: "Vader", poder: 5 };

function rolarDado() {
    return Math.floor(Math.random() * 6) + 1;
}

function iniciarBatalhaSync(p1, p2) {
    console.log("🚀 Iniciando batalha síncrona (Instantânea)...");

    for (let i = 1; i <= 3; i++) {
        const d1 = rolarDado();
        const d2 = rolarDado();
        
        console.log(`\nRound ${i}:`);
        console.log(`${p1.nome} atacou com ${d1 + p1.poder}`);
        console.log(`${p2.nome} atacou com ${d2 + p2.poder}`);
        // O código pula direto para a próxima iteração do 'for'
    }

    console.log("\n🏁 Fim da batalha instantânea! 🏆");
}

iniciarBatalhaSync(pilot, enemy);