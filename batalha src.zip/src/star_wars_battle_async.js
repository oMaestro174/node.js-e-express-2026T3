// --- VERSÃO ASSÍNCRONA ---
// Aqui simulamos um "atraso" (como uma resposta de rede ou tempo de espera).

const pilotAsync = { nome: "Han Solo", poder: 3 };
const enemyAsync = { nome: "Boba Fett", poder: 4 };

// Função auxiliar para criar o "atraso"
// Ela retorna uma Promise que se resolve após 'ms' milissegundos
const esperar = (ms) => new Promise(resolve => setTimeout(resolve, ms));

async function rolarDadoAsync() {
    return Math.floor(Math.random() * 6) + 1;
}

// O 'async' avisa que esta função pode "esperar" por algo
async function iniciarBatalhaAsync(p1, p2) {
    console.log("🌌 Iniciando batalha assíncrona (Com emoção)...");

    for (let i = 1; i <= 3; i++) {
        // O 'await' faz o código parar aqui por 1.5 segundos
        console.log(`\n⏳ Localizando alvos para o Round ${i}...`);
        await esperar(1500); 

        const d1 = await rolarDadoAsync();
        const d2 = await rolarDadoAsync();
        
        console.log(`💥 ROUND ${i}:`);
        console.log(`${p1.nome} disparou: ${d1 + p1.poder}`);
        console.log(`${p2.nome} disparou: ${d2 + p2.poder}`);
    }

    await esperar(1000);
    console.log("\n🏆 Relatório de combate finalizado!");
}

// Como a função é async, precisamos chamá-la
iniciarBatalhaAsync(pilotAsync, enemyAsync);